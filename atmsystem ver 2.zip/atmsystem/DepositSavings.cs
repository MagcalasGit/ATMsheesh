﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class DepositSavings : Form
    {
        public DepositSavings()
        {
            InitializeComponent();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void txtDepositSavings_TextChanged(object sender, EventArgs e)
        {
            int value;
            if (int.TryParse(txtDepositSavings.Text, out value))
            {
                if (value < 0 || value > 9999)
                {
                    MessageBox.Show("Deposit amount exceeds the limit of 9999. Please enter a valid amount.", "Limit Exceeded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtDepositSavings.Text = "";
                }
            }
            else
            {
                txtDepositSavings.Text = "";
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double depositAmount;
            if (double.TryParse(txtDepositSavings.Text, out depositAmount))
            {
                if (!DispenseBills(depositAmount))
                {
                    MessageBox.Show("Unable to dispense the full amount with available bills.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                AccountInfo.chequeAmount += depositAmount;
                txtDepositSavings.Text = "";
                depositChequereceipt receiptForm = new depositChequereceipt(depositAmount);
                this.Hide();
                receiptForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid amount");
            }
        }

        private bool DispenseBills(double withdrawalAmount)
        {
            int[] availableBills = { 1000, 500, 200, 100, 50, 20 };
            foreach (int billValue in availableBills)
            {
                int billCount = (int)(withdrawalAmount / billValue);
                if (billCount > 0)
                {
                    withdrawalAmount %= billValue;
                    continue;
                }
            }

            return withdrawalAmount == 0;
        }

        private void DepositSavings_Load(object sender, EventArgs e)
        {

        }
    }
}
