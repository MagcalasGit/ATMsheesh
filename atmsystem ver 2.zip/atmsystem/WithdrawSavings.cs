﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class WithdrawSavings : Form
    {
        public WithdrawSavings()
        {
            InitializeComponent();
        }

        private void savingsAmount_TextChanged(object sender, EventArgs e)
        {
            double amount;
            if (!double.TryParse(savingsAmount.Text, out amount))
            {
                savingsAmount.Text = "";
                confirmBtn.Enabled = false;
            }
            else
            {
                if (amount > AccountInfo.savingsAmount)
                {
                    confirmBtn.Enabled = false;
                }
                else
                {
                    confirmBtn.Enabled = true;
                }
            }
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            double withdrawalAmount;
            if (!double.TryParse(savingsAmount.Text, out withdrawalAmount))
            {
                MessageBox.Show("Invalid amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (withdrawalAmount > AccountInfo.savingsAmount)
            {
                MessageBox.Show("Insufficient balance", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!DispenseBills(withdrawalAmount))
            {
                MessageBox.Show("Unable to dispense the full amount with available bills.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Perform the withdrawal
            AccountInfo.savingsAmount -= withdrawalAmount;

            // Display receipt
            withdrawSavingsreceipt receipt = new withdrawSavingsreceipt(withdrawalAmount);
            this.Hide();
            receipt.Show();
        }

        private bool DispenseBills(double withdrawalAmount)
        {
            int[] availableBills = { 1000, 500, 200, 100, 50, 20 };
            foreach (int billValue in availableBills)
            {
                int billCount = (int)(withdrawalAmount / billValue);
                if (billCount > 0)
                {
                    withdrawalAmount %= billValue;
                    continue;
                }
            }

            return withdrawalAmount == 0;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            WithdrawSec backtowithdrawSec = new WithdrawSec();
            this.Hide();
            backtowithdrawSec.Show();
        }

        private void WithdrawSavings_Load(object sender, EventArgs e)
        {

        }
    }
}
