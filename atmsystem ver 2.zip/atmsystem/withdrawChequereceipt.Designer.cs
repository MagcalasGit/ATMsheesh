﻿namespace atmsystem
{
    partial class withdrawChequereceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(withdrawChequereceipt));
            lblAccNum = new Label();
            lblAmountDeduc = new Label();
            lblCurrentBal = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(688, 186);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(47, 32);
            lblAccNum.TabIndex = 14;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // lblAmountDeduc
            // 
            lblAmountDeduc.AutoSize = true;
            lblAmountDeduc.BackColor = Color.Transparent;
            lblAmountDeduc.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAmountDeduc.ForeColor = Color.DarkSlateGray;
            lblAmountDeduc.Location = new Point(688, 253);
            lblAmountDeduc.Name = "lblAmountDeduc";
            lblAmountDeduc.Size = new Size(47, 32);
            lblAmountDeduc.TabIndex = 15;
            lblAmountDeduc.Text = "---";
            lblAmountDeduc.Click += lblAmountDeduc_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.AutoSize = true;
            lblCurrentBal.BackColor = Color.Transparent;
            lblCurrentBal.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(688, 316);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(47, 32);
            lblCurrentBal.TabIndex = 16;
            lblCurrentBal.Text = "---";
            lblCurrentBal.Click += lblCurrentBal_Click;
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(456, 390);
            proceedBtn.Margin = new Padding(3, 4, 3, 4);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(336, 52);
            proceedBtn.TabIndex = 17;
            proceedBtn.Text = "Proceed to Merchant";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // withdrawChequereceipt
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1123, 515);
            Controls.Add(proceedBtn);
            Controls.Add(lblCurrentBal);
            Controls.Add(lblAmountDeduc);
            Controls.Add(lblAccNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "withdrawChequereceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "withdrawChequereceipt";
            Load += withdrawChequereceipt_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblAccNum;
        private Label lblAmountDeduc;
        private Label lblCurrentBal;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
    }
}