﻿namespace atmsystem
{
    partial class ChSavingsReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChSavingsReceipt));
            lblAccNum = new Label();
            CurrentBalSavings = new Label();
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            SuspendLayout();
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(663, 178);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(47, 32);
            lblAccNum.TabIndex = 10;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // CurrentBalSavings
            // 
            CurrentBalSavings.AutoSize = true;
            CurrentBalSavings.BackColor = Color.Transparent;
            CurrentBalSavings.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            CurrentBalSavings.ForeColor = Color.DarkSlateGray;
            CurrentBalSavings.Location = new Point(663, 267);
            CurrentBalSavings.Name = "CurrentBalSavings";
            CurrentBalSavings.Size = new Size(47, 32);
            CurrentBalSavings.TabIndex = 11;
            CurrentBalSavings.Text = "---";
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(447, 326);
            proceedBtn.Margin = new Padding(3, 4, 3, 4);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(186, 57);
            proceedBtn.TabIndex = 12;
            proceedBtn.Text = "Proceed";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.LightCyan;
            guna2HtmlLabel1.Location = new Point(646, 167);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(11, 43);
            guna2HtmlLabel1.TabIndex = 13;
            guna2HtmlLabel1.Text = ":";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.LightCyan;
            guna2HtmlLabel2.Location = new Point(646, 256);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(11, 43);
            guna2HtmlLabel2.TabIndex = 14;
            guna2HtmlLabel2.Text = ":";
            // 
            // ChSavingsReceipt
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1068, 439);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(proceedBtn);
            Controls.Add(CurrentBalSavings);
            Controls.Add(lblAccNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "ChSavingsReceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ChSavingsReceipt";
            Load += ChSavingsReceipt_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblAccNum;
        private Label CurrentBalSavings;
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
    }
}