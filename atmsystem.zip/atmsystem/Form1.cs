namespace atmsystem
{
    public partial class Form1 : Form
    {
        private int maxLoginAttempts = 3;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAccNum_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtAccNum.Text) && !char.IsDigit(txtAccNum.Text[txtAccNum.Text.Length - 1]))
            {
                txtAccNum.Text = txtAccNum.Text.Remove(txtAccNum.Text.Length - 1);
                txtAccNum.SelectionStart = txtAccNum.Text.Length;
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ShowHidPIN_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowHidPIN.Checked && txtPIN.UseSystemPasswordChar == true)
            {
                txtPIN.UseSystemPasswordChar = false;
            }
            else
            {
                txtPIN.UseSystemPasswordChar = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtPIN.UseSystemPasswordChar = true;
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (txtAccNum.Text == "0000" && txtPIN.Text == "0000")
            {
                MainPage mainpage = new MainPage();
                this.Hide();
                mainpage.Show();
            }
            else
            {
                maxLoginAttempts--;
                if (maxLoginAttempts > 0)
                {
                    MessageBox.Show($"Incorrect username or passsword. You have {maxLoginAttempts} attempts remaining.");
                    txtAccNum.Text = "";
                    txtPIN.Text = "";
                }
                else
                {

                    MessageBox.Show("Maximum login attempts exceeded. Account disabled.");
                }
            }
        }
    }
}
