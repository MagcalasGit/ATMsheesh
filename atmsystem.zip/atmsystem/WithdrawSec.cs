﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class WithdrawSec : Form
    {
        public WithdrawSec()
        {
            InitializeComponent();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void WithdrawSavingsBtn_Click(object sender, EventArgs e)
        {
            WithdrawSavings gowithdrawSavings = new WithdrawSavings();
            this.Hide();
            gowithdrawSavings.Show();
        }

        private void WithdrawChequeBtn_Click(object sender, EventArgs e)
        {
            WithdrawCheque gowithdrawCheque = new WithdrawCheque();
            this.Hide();
            gowithdrawCheque.Show();
        }

        private void WithdrawSec_Load(object sender, EventArgs e)
        {

        }
    }
}
