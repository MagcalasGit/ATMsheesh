﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class withdrawChequereceipt : Form
    {
        private double withdrawalamount;
        public withdrawChequereceipt(double withdrawalamount)
        {
            InitializeComponent();
            this.withdrawalamount = withdrawalamount;
        }

        private void withdrawChequereceipt_Load(object sender, EventArgs e)
        {
            lblAccNum.Text = AccountInfo.accountNumber;
            lblAmountDeduc.Text = withdrawalamount.ToString();
            lblCurrentBal.Text = AccountInfo.chequeAmount.ToString();
        }

        private void lblAccNum_Click(object sender, EventArgs e)
        {

        }

        private void lblAmountDeduc_Click(object sender, EventArgs e)
        {
            if (double.TryParse(lblAmountDeduc.Text, out double amount))
            {
                lblAmountDeduc.Text = amount.ToString("0.00");
            }
        }

        private void lblCurrentBal_Click(object sender, EventArgs e)
        {
            if(double.TryParse(lblCurrentBal.Text, out double currentBalance))
            {
                lblCurrentBal.Text = currentBalance.ToString("0.00");
            }
        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to go back to the main page?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                MainPage backtoMain = new MainPage();
                this.Hide();
                backtoMain.Show();
            }
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
