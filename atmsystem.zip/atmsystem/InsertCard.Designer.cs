﻿namespace atmsystem
{
    partial class InsertCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertCard));
            txtCardNum = new Guna.UI2.WinForms.Guna2TextBox();
            enterBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // txtCardNum
            // 
            txtCardNum.BackColor = Color.Transparent;
            txtCardNum.BorderColor = Color.DarkCyan;
            txtCardNum.BorderRadius = 20;
            txtCardNum.BorderThickness = 2;
            txtCardNum.CustomizableEdges = customizableEdges1;
            txtCardNum.DefaultText = "";
            txtCardNum.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCardNum.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCardNum.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCardNum.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCardNum.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCardNum.Font = new Font("Segoe UI", 9F);
            txtCardNum.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCardNum.Location = new Point(419, 234);
            txtCardNum.Margin = new Padding(3, 5, 3, 5);
            txtCardNum.Name = "txtCardNum";
            txtCardNum.PasswordChar = '\0';
            txtCardNum.PlaceholderText = "Card Number";
            txtCardNum.SelectedText = "";
            txtCardNum.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtCardNum.Size = new Size(296, 54);
            txtCardNum.TabIndex = 2;
            txtCardNum.TextChanged += txtCardNum_TextChanged;
            // 
            // enterBtn
            // 
            enterBtn.BackColor = Color.Transparent;
            enterBtn.BorderColor = Color.DarkSlateGray;
            enterBtn.BorderRadius = 15;
            enterBtn.BorderThickness = 2;
            enterBtn.CustomizableEdges = customizableEdges3;
            enterBtn.DisabledState.BorderColor = Color.DarkGray;
            enterBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            enterBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            enterBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            enterBtn.FillColor = Color.Teal;
            enterBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            enterBtn.ForeColor = Color.White;
            enterBtn.Location = new Point(419, 352);
            enterBtn.Margin = new Padding(3, 4, 3, 4);
            enterBtn.Name = "enterBtn";
            enterBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            enterBtn.Size = new Size(138, 41);
            enterBtn.TabIndex = 5;
            enterBtn.Text = "Enter";
            enterBtn.Click += enterBtn_Click;
            // 
            // InsertCard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(enterBtn);
            Controls.Add(txtCardNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "InsertCard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "InsertCard";
            Load += InsertCard_Load;
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtCardNum;
        private Guna.UI2.WinForms.Guna2Button enterBtn;
    }
}